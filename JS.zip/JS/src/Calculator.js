 
  var Calculator = function Calculator(a, b)
  {
  
    this.add = function(a, b) 
      { 
        return a + b; 
      }
    this.subtract = function(a, b) 
      { 
        return a - b; 
      }
   this.multiply = function(a, b) 
      { 
        return a * b; 
      }
    this.divide = function(a, b) 
      {
      if (a/b === Infinity) 
        {
          return NaN;
        } 
      else 
        return a/b;
      }
  }
//var calculator = new Calculator();

// calculator.add(1,2);
// calculator.subtract(9,2);
// calculator.multiply(4,3);
// calculator.divide(10,2);


 var ScientificCalculator = function()
 {
  ScientificCalculator.prototype = new Calculator();
  this.constructor = Calculator;
  ScientificCalculator.prototype instanceof  Calculator;
// inheritsFrom(ScientificCalculator.prototype, Calculator);

// Adding methods to the base class
  this.sin = function(x) 
  {
    return Math.sin(x);
  }
  this.cos = function(x) 
  {
    return Math.cos(x);
  }
  this.tan = function(x) 
  {
    return Math.tan(x);
  }
  this.log = function(x) 
  {
    return Math.log(x);
  }
  }
// var calculator = new ScientificCalculator();

// calculator.sin(Math.PI/2);
// calculator.cos(Math.PI);
// calculator.tan(0);
// calculator.log(1);

